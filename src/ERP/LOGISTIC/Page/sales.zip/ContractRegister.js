import React, { useState } from "react";
import { Button, TextField, makeStyles, Typography } from "@material-ui/core";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-theme-material.css";
import "ag-grid-community/dist/styles/ag-grid.css";

function useInput(initialValue) {
  const [value, setValue] = useState(initialValue);
  const onChange = event => {
    setValue(event.target.value);
  };

  const set = str => {
    setValue(str);
  };

  return { value, onChange, setValue: set };
}
const useStyles = makeStyles(theme => ({
  labelStyle: {
    color: "gray",
    padding: theme.spacing(2),
  },
  btnSearch: {
    fontSize: "1.3rem",
    backgroundColor: "rosybrown",
    color: "white",
    fontWeight: "bold",
    outline: "none",
    borderRadius: "4px",
    cursor: "pointer",
    border: "none",
    width: "20%",
    height: "20%",
    padding: theme.spacing(1),
  },
  hrStyle: {
    opacity: "0.4",
  },
  btnStyle: {
    color: "white",
    fontWeight: "600",
    fontSize: "20px",
    backgroundColor: "rosybrown",
  },
}));

const gridFrameStyle = {
  height: "300px",
  width: "90%",
  backgroundColor: "gainsboro",
};

const headerName = [
  {
    headerName: "",
    checkboxSelection: true,
    width: 50,
    headerCheckboxSelection: true,
  },
  { headerName: "견적일련번호", field: "estimateNo", width: 150 },
  { headerName: "수주일련번호", field: "contractNo", width: 150 },
  {
    headerName: "수주유형이름",
    field: "contractStatusName",
    width: 150,
    editable: true,
  },

  { headerName: "거래처명", field: "customerName", width: 150 },
  { headerName: "수주일자", field: "contractDate", width: 150 },
  {
    headerName: "수주요청자",
    field: "contractRequester",
    width: 150,
    editable: true,
  },

  { headerName: "수주담당자", field: "contractInCharge", width: 150 },
  {
    headerName: "견적유효일자",
    field: "effectiveDate",
    width: 150,
    editable: true,
  },
  {
    headerName: "견적요청자",
    field: "estimateRequester",
    width: 150,
    editable: true,
  },

  { headerName: "비고", field: "description", width: 150, editable: true },
];

const estimateDetail = [
  { headerName: "견적상세일련번호", field: "estimateDetailNo", width: 170 },
  { headerName: "견적일련번호", field: "estimateNo", width: 170 },
  {
    headerName: "품목코드",
    field: "itemCode",
    width: 170,
  },

  { headerName: "품목명", field: "itemName", width: 170 },
  { headerName: "단위", field: "unitOfContract", width: 170 },
  {
    headerName: "납기일",
    field: "dueDateOfContrct",
    width: 170,
  },

  {
    headerName: "견적단가",
    field: "unitPriceOfEstimate",
    width: 170,
  },

  {
    headerName: "처리상태",
    field: "processStatus",
    width: 170,
  },
];

const searchEstimate = e => {};
const ContractRegister = () =>
  /* 견적 컴포넌트 들고옴 */

  {
    const classes = useStyles();
    const startDate = useInput();
    const endDate = useInput();
    return (
      <React.Fragment>
        <>
          <br />
          <div>
            <Typography className={classes.labelStyle}>시작일</Typography>
            <TextField id={"startDate"} type={"date"}></TextField>
            &nbsp;
            <Typography className={classes.labelStyle}>종료일</Typography>
            <TextField id={"endDate"} type={"date"}></TextField>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <Button className={classes.btnSearch} onClick={searchEstimate}>
              수주 가능 견적 조회
            </Button>
          </div>
          <br />
          <hr className={classes.hrStyle} />
          <div className="contract_body1">
            <div className={"ag-theme-material"} style={gridFrameStyle}>
              <AgGridReact columnDefs={headerName} />
            </div>
          </div>
          <br />
          <hr className={classes.hrStyle} />
          <br />
          <div>
            <Button className={classes.btnStyle}>수주 등록하기</Button>
            <br />
            <hr className={classes.hrStyle} />
            <div className={"ag-theme-material"} style={gridFrameStyle}>
              <AgGridReact
                columnDefs={estimateDetail}

                /*     rowData={rowData} */
              />
            </div>
          </div>
        </>
      </React.Fragment>
    );
  };

export default ContractRegister;
